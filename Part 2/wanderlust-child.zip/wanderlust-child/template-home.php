<?php
/**
 * Template Name: Travel Blog Home Page
 */

get_header();
?>

<div id="content" class="site-content" role="main" style="background-image: url(<?php echo get_stylesheet_directory_uri() . '/images/banner.png';?>);">
	<div id="homeTitle" >
		<h1>Wanderlust</h1>
		<p>Travel Blog</p>
	</div>
	<div id="homeCTA" >
		<button><a id="homeBtn" href="/blog">Discover</a></button>
	</div>



</div><!-- #content -->

<?php get_footer(); ?>



