<?php

// Enqueue Ion parent theme CSS file

add_action( 'wp_enqueue_scripts', 'appp_ion_enqueue_styles' );
function appp_ion_enqueue_styles() {
	// parent theme css
	$version = AppPresser_Ion_Theme_Setup::VERSION . '.' . filemtime( get_template_directory() . '/style.css' );
    wp_enqueue_style( 'ion-style', get_template_directory_uri().'/style.css', null, $version );
    
    // child theme css
    wp_enqueue_style( 'ion-child-style', get_stylesheet_uri(), null, filemtime( get_stylesheet_directory() . '/style.css' ) );

    // child theme js
    wp_enqueue_script( 'wc-js', get_stylesheet_directory_uri() . '/js/wordcamp.js', array('jquery'), '1.0.0', true );

}

// Add your custom functions here

function wcct_appp_back_button() {

    $classname = '';

    if( class_exists( 'AppTransitions' ) ) {
        $classname = apply_filters('appp_transition_right', $classname );
    }

    if ( !is_front_page() ) {
        $lr_arrow = is_rtl() ? 'forward' : 'back';
        echo '<button class="button-back-button button-clear nav-left-btn ' . apply_filters('appp_transition_right', $classname ) . '"><i class="icon ion-ios-arrow-'.$lr_arrow.'"></i></button>';
    }
}
add_action( 'wcct_appp_header_left', 'wcct_appp_back_button' );