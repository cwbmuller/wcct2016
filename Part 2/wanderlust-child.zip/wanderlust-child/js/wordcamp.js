jQuery(document).ready(OnloadFunction);
function OnloadFunction($){

    $('ul.wctabs li').click(function(){
        var tab_id = $(this).attr('data-tab');

        $('ul.wctabs li').removeClass('current');
        $('.wctab-content').removeClass('current');

        $(this).addClass('current');
        $("#"+tab_id).addClass('current');
    })

    $('#nav-left-open').on('click', function() { $(this).toggleClass('active'); });

    $('.button-back-button').on('click', function() { window.history.back(); });

};