<div id="buddypress">

		<div id="members-dir-list" class="members dir-list">
			<?php bp_get_template_part( 'members/members-loop' ); ?>
		</div><!-- #members-dir-list -->

	</form><!-- #members-directory-form -->

</div><!-- #buddypress -->
