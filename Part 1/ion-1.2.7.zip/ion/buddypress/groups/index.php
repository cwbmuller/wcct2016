<div id="buddypress">

	<div id="groups-dir-list" class="groups dir-list">
		<?php bp_get_template_part( 'groups/groups-loop' ); ?>
	</div><!-- #groups-dir-list -->

</div><!-- #buddypress -->